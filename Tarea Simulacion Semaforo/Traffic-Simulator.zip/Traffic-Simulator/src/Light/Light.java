package Light;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Timer;

public class Light implements ActionListener {
	// El background de las luces de los semaforos
	private Image bkLight;
	private Timer tm;
	private Vector position;
	private int tiempoSem = 1000;
	//Clase hace un mapeo a 2D
	private AffineTransform trans;
	// Interfaz asincronica para inf de la imagen
	private ImageObserver imgObs;
	private int id, timer =0;
	private Color[] currentColor;
	// Estados de las luces rojo(1),amarrillo(2) y verde(3)
	public enum TrafficState{RED,YELLOW,GREEN};
	public boolean forwardGo;
	//Posiciones de las luces
	private Vector left_light_pos;
	private Vector right_light_pos;
	private Vector forward_pos;
	private int trafficTime = 2;
	private int orientation; // 0 -Horizontal, 1-Vertical
	
	public Vector getLeft_light_pos() {return left_light_pos;}
	public void setLeft_light_pos(Vector left_light_pos) {this.left_light_pos = left_light_pos;}


	public Vector getRight_light_pos() {return right_light_pos;}
	public void setRight_light_pos(Vector right_light_pos) {this.right_light_pos = right_light_pos;}
	
	public int getTiempoSem() { return this.tiempoSem;}
	public void setTiempoSem(int tiempo) { this.tiempoSem = 1000-(2*tiempo); }

	public Vector getForward_pos() {return forward_pos;}
	public void setForward_pos(Vector forward_pos) {this.forward_pos = forward_pos;}
	
	public Light(File imgsrc,int x, int y, int angle, int orient, int id, ImageObserver imgOb) {
		this.imgObs = imgOb;
		this.trans = new AffineTransform();
		this.orientation = orient;
		// Pasos de los carros
		this.forwardGo = false;
		
		this.tm = new Timer(1,this);
		this.id = id;
		this.currentColor = new Color[3]; //index 0-Izquierda, 1-Derecho, 2-Derecha
		this.currentColor[0] = Color.red; currentColor[1] = Color.red; currentColor[2] = Color.red;
		
		try {
			this.bkLight = ImageIO.read(imgsrc);
			this.tm = new Timer(1, this);
			this.position = new Vector(x,y);
			this.trans.setToTranslation(this.position.x, this.position.y);
			this.trans.rotate(Math.toRadians(angle),this.bkLight.getWidth(imgOb)/2,this.bkLight.getHeight(imgOb)/2);
			
		}catch(IOException err) {
			System.err.println(err);
		}
		this.tm.start();
	}
	public int getOrientation() {return this.orientation;}

	public AffineTransform getTrans() {return this.trans;}

	public void setTrans(AffineTransform trans) {this.trans = trans;}
	public Image getbkLight() {return this.bkLight;}
	public void setbkLight(Image layoutImg) {this.bkLight = layoutImg;}
	public Vector getPosition() {return this.position;}

	public void setPosition(Vector position) {this.position = position;}

	public Color[] getCurrentColor() {return this.currentColor;}
	
	
	public void actionPerformed(ActionEvent e) {
		this.timer++;
		if(this.id==1) {
			if(this.timer > 550 && this.timer < (this.trafficTime*this.tiempoSem)-700) {
				this.forwardGo = true;
			}
			if(this.timer< this.trafficTime*this.tiempoSem && this.timer > (this.trafficTime*this.tiempoSem)-499) {
				this.forwardGo = false;
				this.currentColor[1] = Color.yellow;
			}
			if(this.timer > this.trafficTime*this.tiempoSem) {
				this.currentColor[1] = Color.red;
			}
			if(this.timer > (this.trafficTime+4)*this.tiempoSem) {
				this.timer = 0;
			}
		}
		if(this.id == 2) {
			if(timer > trafficTime*this.tiempoSem && timer < ((trafficTime+4)*this.tiempoSem)-500){
				forwardGo = true;
			}
			
			if(timer < (trafficTime+4)*this.tiempoSem && timer > ((trafficTime+4)*this.tiempoSem)-499){
				forwardGo = false;
				this.currentColor[1] = Color.yellow;
			}
			
			if(timer > (trafficTime+4)*this.tiempoSem){
				this.currentColor[1] = Color.red;
			}
			if(timer > (trafficTime+4)*this.tiempoSem){
				timer = 0;
			}
		}
		if(this.id == 3) {
			if(timer > 550 && timer < (trafficTime*this.tiempoSem)-700){
				forwardGo = true;
			}
			if(timer < trafficTime*this.tiempoSem && timer >(trafficTime*this.tiempoSem)-499){
				this.forwardGo = false;
				this.currentColor[1] = Color.yellow;
			}
			if(timer > trafficTime*this.tiempoSem){
				this.forwardGo = false;
				this.currentColor[1] = Color.red;
			}
			if(timer > (trafficTime+4)*this.tiempoSem){
				this.timer = 0;
			}
		}
		if(this.id ==4) {
			if(timer > trafficTime*this.tiempoSem && timer < ((trafficTime+4)*this.tiempoSem)-500){
				this.forwardGo = true;
			}
			
			if(timer < (trafficTime+4)*this.tiempoSem && timer > ((trafficTime+4)*this.tiempoSem)-499){
				this.forwardGo = false;
				this.currentColor[1] = Color.yellow;
			}
			
			if(timer > (trafficTime+4)*this.tiempoSem){
				this.currentColor[1] = Color.red;
				this.timer =0;
			}
		}
		if(forwardGo){
			this.currentColor[1] = Color.green;
		}
		
	}
	
	
	
}
