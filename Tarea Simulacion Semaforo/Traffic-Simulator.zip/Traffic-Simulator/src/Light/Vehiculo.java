package Light;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.Timer;

public class Vehiculo implements ActionListener {
	private Light trafficLight;
	private ImageObserver imgObs;
	// Imagen del vehiculo
	private Image vImage;
	// Aceleracion del vehiculo
	private float velocidad, acceleration = 0f, vehVelo;
	// Angulo del vehiculo actual
	private float mCurAngle;
	// Dirreccion de los vehiculos
	public enum VehicleDirection{LEFT, RIGHT, UP, DOWN};
	public enum VehicleState{BRAKE, MOVE_X, MOVE_Y};
	
	// Posicion del vehiculo
	private Vector vehiclePosition;
	private Timer tiempo;
	
	private VehicleState vAnterior, vActual;
	private VehicleDirection vDirection;
	private AffineTransform transf;
	
	private boolean passedTrafficLight;
	
	//Active Cruise Control variables
	private Vehiculo vehicleAhead;
	
	//Traffic lights position constants that vehicles should pass
	private final int movingRightPos = 301;		//vehiculo posicion x
	private final int movingLeftPos = 1150;		//vehiculo posicion x
	private final int movingDownPos = 121;		//vehiculo posicion y
	private final int movingUpPos = 652;		//vehiculo posicin y
	
	
	//Position Constants
	private Vector RIGHT_LEFT_POS = new Vector(1500,265);
	private Vector LEFT_RIGHT_POS = new Vector(-300, 463);
	private Vector DOWN_UP_POS = new Vector(920, 840);
	private Vector UP_DOWN_POS = new Vector(520, -100);
	
	//Junction Turning Constants
	
	//A turning constant
	private boolean turn = false;
	
	/** 
	 * Constructor for class
	 * Sets the current vehicle state to BRAKE
	 * Sets current angle to 0
	 * @param src Loads the vehicle image
	 * @param vel Sets the vehicle max speed
	 * @param x_pos Defines the x-position of the vehicle
	 * @param y_pos Defines the y-position of the vehicle
	 * */
	
	public Vehiculo(File src, int vel, VehicleState moveX, VehicleDirection right, Light tl,ImageObserver imObs, Vehiculo vAhead, int index){
		this.vActual = moveX;
		this.vehicleAhead = vAhead;
		this.vAnterior = this.vActual;						//store previous state of vehicle
		this.vDirection = right;
		this.imgObs = imObs;
		this.trafficLight = tl;
		try {
			this.vImage = ImageIO.read(src);
			switch(index%3){
			case 0:
				UP_DOWN_POS = new Vector(UP_DOWN_POS.x + 100, UP_DOWN_POS.y);
				DOWN_UP_POS = new Vector(DOWN_UP_POS.x + 100, DOWN_UP_POS.y);
				LEFT_RIGHT_POS = new Vector(LEFT_RIGHT_POS.x, LEFT_RIGHT_POS.y + 70);
				RIGHT_LEFT_POS = new Vector(RIGHT_LEFT_POS.x, RIGHT_LEFT_POS.y + 60);
				break;
			case 1:
				break;
			case 2:
				UP_DOWN_POS = new Vector(UP_DOWN_POS.x - 120, UP_DOWN_POS.y);	
				DOWN_UP_POS = new Vector(DOWN_UP_POS.x - 100, DOWN_UP_POS.y);
				LEFT_RIGHT_POS = new Vector(LEFT_RIGHT_POS.x, LEFT_RIGHT_POS.y - 70);
				RIGHT_LEFT_POS = new Vector(RIGHT_LEFT_POS.x, RIGHT_LEFT_POS.y - 70);
				break;
			}
			
			//Set vehicle position according to the direction it's moving to
			switch(right){
			case LEFT:
				if(vehicleAhead != null && vehicleAhead.vehiclePosition.x> movingLeftPos){
					this.vehiclePosition = new Vector(vehicleAhead.vehiclePosition.x + 300, this.RIGHT_LEFT_POS.y);
				}else{
					this.vehiclePosition = RIGHT_LEFT_POS;
				}
				break;
			
			case RIGHT:
				if(vehicleAhead != null && vehicleAhead.vehiclePosition.x < movingRightPos){
					vehiclePosition = new Vector(vehicleAhead.vehiclePosition.x - 300, LEFT_RIGHT_POS.y);
				}else
					vehiclePosition = LEFT_RIGHT_POS;
				break;
			
			case UP:
				if(vehicleAhead != null && vehicleAhead.vehiclePosition.y > movingUpPos){
					vehiclePosition = new Vector(DOWN_UP_POS.x, vehicleAhead.vehiclePosition.y + 200);
				}else
					vehiclePosition = DOWN_UP_POS;
				break;
			
			case DOWN:
				if(vehicleAhead != null && vehicleAhead.vehiclePosition.y <= movingDownPos){
					vehiclePosition = new Vector(UP_DOWN_POS.x, vehicleAhead.vehiclePosition.y - 200);
				}else
					vehiclePosition = UP_DOWN_POS;
				break;
			}
			
			this.transf = new AffineTransform();
			this.velocidad = vel;
			this.vehVelo = velocidad;
			this.mCurAngle = 0;
			this.transf.setToTranslation(vehiclePosition.x, vehiclePosition.y);
			
			if(vActual == VehicleState.MOVE_Y){
				this.mCurAngle = 90;
				this.transf.setToTranslation(vehiclePosition.x, vehiclePosition.y);
				this.transf.rotate(Math.toRadians(mCurAngle), vImage.getWidth(imgObs)/2,vImage.getHeight(imgObs)/2);
			}
			
			this.tiempo = new Timer(10,this);
			this.tiempo.start();
			
			
		} catch (IOException e) {
			System.out.println("Can't find image");
			e.printStackTrace();
		}
	}
	public VehicleState getvActual() {return this.vActual;}
	public void setvActual(VehicleState vState) {this.vActual = vState;}

	public VehicleDirection getvDirection() {return this.vDirection;}
	public void setvDirection(VehicleDirection vDirection) {this.vDirection = vDirection;}
	
	/** 
	 * Getter for vehicle image
	 * @return Image The vehicle image object*/

	public Image getImage() {return this.vImage;}
	public void setImage(Image image) {this.vImage = image;}

	public float getSpeed() {return this.velocidad;}
	public void setSpeed(int speed) {this.velocidad = speed;}

	public float getCurAngle() {return this.mCurAngle;}
	public void setCurAngle(float curAngle) {this.mCurAngle = curAngle;}

	public boolean hasPassedTrafficLight() {return this.passedTrafficLight;}


	public Vector getVehiclePosition() {return this.vehiclePosition;}
	public void setVehiclePosition(Vector vehiclePosition) {this.vehiclePosition = vehiclePosition;}
	
	public AffineTransform getTransf(){return this.transf;}
	
	public boolean isInView(){
		if(vDirection == VehicleDirection.LEFT && vehiclePosition.x < -100){
			return false;
		}
		if(vDirection == VehicleDirection.RIGHT && vehiclePosition.x > 1500){
			return false;
		}
		if(vDirection == VehicleDirection.UP && vehiclePosition.y < -100){
			return false;
		}
		if(vDirection == VehicleDirection.DOWN && vehiclePosition.y > 850){
			return false;
		}
		
		return true;
	}
	
	private void accelerate(int current_pos, int final_pos){
		float dist = final_pos - current_pos;
		float t = dist/velocidad;
		
		if(Math.abs(t) > 0)
			acceleration = (0-velocidad)/t;
		else
			acceleration = 0;
		
	}
	
	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub	
		
		
		if(vehicleAhead != null && !vehicleAhead.isInView()){
			vehicleAhead = null;
		}
		
		if(trafficLight != null && (trafficLight.forwardGo || passedTrafficLight) && !turn){
			vActual = vAnterior;
		}else if(trafficLight != null && !trafficLight.forwardGo){
			//vPrev = vState;
			vActual = VehicleState.BRAKE;		
		}
		
		switch(vActual){
		case BRAKE:
			switch(vDirection){
		
			case UP:
				mCurAngle = -90;
				if(velocidad > 0){
					velocidad *= -1;
				}
				
				if(vehicleAhead!= null && vehicleAhead.passedTrafficLight)
					vehicleAhead = null;
				
				if(vehicleAhead == null){
					accelerate(vehiclePosition.y, movingUpPos);
					velocidad += acceleration;
					if(vehiclePosition.y >= movingUpPos){
						this.vehiclePosition.y += velocidad;
					}
				}else{
					if(vehicleAhead.vehiclePosition.y > 650 && vehicleAhead.vehiclePosition.y > movingUpPos){
						accelerate(vehiclePosition.y, vehicleAhead.vehiclePosition.y + 150);
						velocidad += acceleration;
						if(vehiclePosition.y > vehicleAhead.vehiclePosition.y + 150){
							
							this.vehiclePosition.y += velocidad;
						}
					}
				}
				break;
			case DOWN:
				if(vehicleAhead != null && vehicleAhead.passedTrafficLight)
					vehicleAhead = null;
				
				if(acceleration > 0)		//new
					acceleration *= -1;
				
				if(vehicleAhead == null){
					accelerate(vehiclePosition.y, movingDownPos);
					velocidad += acceleration;
					if(vehiclePosition.y <= movingDownPos){
						
						this.vehiclePosition.y += velocidad;
					}
										
				}else{
					
					if(vehicleAhead.vehiclePosition.y > -50 && vehicleAhead.vehiclePosition.y < movingDownPos){
						accelerate(vehiclePosition.y, vehicleAhead.vehiclePosition.y - 140);
						velocidad += acceleration;
						if(vehiclePosition.y <= vehicleAhead.vehiclePosition.y - 140){
							
							this.vehiclePosition.y += velocidad;
						}
					}
				}
				
				break;
			default:
				break;
			}
			
			this.transf.setToTranslation(vehiclePosition.x, vehiclePosition.y);
			this.transf.rotate(Math.toRadians(mCurAngle), vImage.getWidth(this.imgObs)/2, vImage.getHeight(imgObs)/2);
			break;
				
		case MOVE_X:
			velocidad = vehVelo*2;		//velocidad
			
			if(vDirection == VehicleDirection.LEFT){
				if(!passedTrafficLight && !trafficLight.forwardGo)
					vActual = VehicleState.BRAKE;
				
				if(vehiclePosition.x < movingLeftPos && !turn){
					passedTrafficLight = true;
				}
				if(velocidad > 0){
					velocidad *= -1;
					mCurAngle = 180;
				}
				if(vehicleAhead != null){
					accelerate(vehiclePosition.x, vehicleAhead.vehiclePosition.x + 120);
					if(acceleration > 0){
						acceleration = 0;
						velocidad = vehicleAhead.getSpeed();
					}
					velocidad += acceleration;
				}
				
			}else if(vDirection == VehicleDirection.RIGHT){
				if(!passedTrafficLight && !trafficLight.forwardGo)
					vActual = VehicleState.BRAKE;
				
				if(vehiclePosition.x > movingRightPos){
					passedTrafficLight = true;
				}
				if(velocidad < 0){
					velocidad *= -1;
					mCurAngle = 0;
				}
				if(vehicleAhead != null){
					if(acceleration > 0)
						accelerate(vehiclePosition.x, vehicleAhead.vehiclePosition.x - 150);
					else
						acceleration = 0;
					acceleration *= -1;
					velocidad += acceleration;
				}
			}
			
			this.vehiclePosition.x += velocidad;
			this.transf.setToTranslation(vehiclePosition.x, vehiclePosition.y);
			this.transf.rotate(Math.toRadians(mCurAngle), vImage.getWidth(this.imgObs)/2, vImage.getHeight(this.imgObs)/2);
			break;
			
		case MOVE_Y:
			velocidad = vehVelo;
			switch(vDirection){
			case UP:
				if(vehicleAhead != null && vehicleAhead.vActual != this.vActual){
					velocidad = vehicleAhead.velocidad;
					vehicleAhead = null;
					
				}
				if(!passedTrafficLight && !trafficLight.forwardGo){
					vActual = VehicleState.BRAKE;
					
				}
				if(vehiclePosition.y < movingUpPos){
					passedTrafficLight = true;
				}
				if(velocidad > 0){		//Moving down
					velocidad *= -1;
					mCurAngle = -90;
				}
				if(vehicleAhead != null){
					accelerate(vehiclePosition.y, vehicleAhead.vehiclePosition.y + 130);
					velocidad += acceleration;
				}
				break;
			
			case DOWN:
				
				if(!passedTrafficLight && !trafficLight.forwardGo)
					vActual = VehicleState.BRAKE;
				
				if(vehiclePosition.y > movingDownPos){
					passedTrafficLight = true;
				}
				if(velocidad < 0){
					mCurAngle = 90;
					velocidad *= -1;
				}
				if(vehicleAhead != null){
					accelerate(vehiclePosition.y, vehicleAhead.vehiclePosition.y - 150);
					if(acceleration < 0){
						acceleration = 0;
						velocidad = vehicleAhead.getSpeed();
					}
					acceleration *= -1;
					velocidad += acceleration;
				}
				
				if(vehicleAhead != null && vehicleAhead.vActual != this.vActual){
					velocidad = vehicleAhead.velocidad;
					vehicleAhead = null;
				}
				break;
			default:
				break;
			
			}
			this.vehiclePosition.y += velocidad;
			this.transf.setToTranslation(vehiclePosition.x, vehiclePosition.y);
			this.transf.rotate(Math.toRadians(mCurAngle), vImage.getWidth(this.imgObs)/2, vImage.getHeight(imgObs)/2);

			break;
		}
			
	}
}
